package com.example.bikeshare.Activities;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.widget.*;

import com.example.bikeshare.R;
import com.example.bikeshare.Ride;
import com.example.bikeshare.RidesDB;

import io.realm.Realm;
import io.realm.RealmResults;

public class StartRideActivity extends Activity {
    // GUI variables
    private Button mAddRide;
    private TextView mNewWhat;
    private TextView mNewWhere;
    private Ride mRide = new Ride("", "", "");
    private static RidesDB sRidesDB;
    private Realm realm;
    BikeShareActivity bActivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sRidesDB = RidesDB.get(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_ride);

        // Button
        mAddRide = (Button) findViewById(R.id.addRide_button);

        // Texts
        mNewWhat = (TextView) findViewById(R.id.what_text);
        mNewWhere = (TextView) findViewById(R.id.where_text);



        //View products click event
        mAddRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((mNewWhat.getText().length() > 0) && (mNewWhere.getText().length() > 0)) {
                    mRide.setBikeName(mNewWhat.getText().toString().trim());
                    mRide.setStartRide(mNewWhere.getText().toString().trim());

                    Ride obj = realm.createObject(Ride.class);
                    obj.setBikeName(mNewWhat.getText().toString());
                    obj.setBikeName(mNewWhere.getText().toString());
                    realm.commitTransaction();

                    //Adding rides to list
                    sRidesDB.addRide(mNewWhat.getText().toString(), mNewWhere.getText().toString());

                    //PopUp to show success
                    Toast toast = Toast.makeText(StartRideActivity.this, "Start ride added", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, -200);
                    toast.show();

                    // Reset text fields
                    mNewWhat.setText("");
                    mNewWhere.setText("");
                }
            }
        });
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        realm.close();
    }
}