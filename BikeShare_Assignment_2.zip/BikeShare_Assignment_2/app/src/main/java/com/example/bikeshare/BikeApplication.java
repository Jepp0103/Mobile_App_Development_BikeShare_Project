package com.example.bikeshare;

import android.app.Application;

import io.realm.Realm;

public class BikeApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
    }
}
